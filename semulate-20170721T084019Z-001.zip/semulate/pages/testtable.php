 <!DOCTYPE html>
  <html>
   <head>
    <script type="text/javascript" 
       src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
   </head>
   <body>
    <?php
    $json=file_get_contents("http://www.pttmap.com/station.cshtml?page=1&keyword=%E0%B8%9B%E0%B8%95%E0%B8%97&latitude=13.752222&longitude=100.493889&mode=search&_=1500551675125");
            //$data =  json_decode($json);

        //if (count($data)) {
            // Open the table
            

            // Cycle through the array
//            foreach ($data['results'] as $stand) {
//
//                // Output a row
//                print_r($stand);
//            }
            
//            foreach ($data as $stand) {
//                print_r($stand);
//        }
      $jarray = json_decode($json, true);

foreach ($jarray as $value) {
    foreach ($value as $key => $val) {
        echo $key;
        echo $val;
    }
}
      //  }
    ?>
  </body>
</html>